package Personajes;

import com.badlogic.gdx.graphics.Texture;

import java.awt.Rectangle;


public class MM  extends Personaje{
    public MM(int vidas, int fuerza, int velocidad, float width, float height, int positionx,
              int positiony, Texture imagen, Rectangle hitbox) {
        super(vidas, fuerza, velocidad, width, height, positionx, positiony, imagen,hitbox);
    }
}
