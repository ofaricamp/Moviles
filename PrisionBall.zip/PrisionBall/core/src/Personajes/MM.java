package Personajes;

import com.badlogic.gdx.graphics.Texture;

public class MM  extends Personaje{
    public MM(int vidas, int fuerza, int velocidad, float width, float height, int positionx, int positiony, Texture imagen) {
        super(vidas, fuerza, velocidad, width, height, positionx, positiony, imagen);
    }
}
