package Personajes;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;

public class Personaje {
    private int vidas = 3;
    private int fuerza = 1;
    private int velocidad = 1;
    private Vector3 velocity;
    private Vector3 position;

    public void updatePosition(){

    }

    public void move(){
        if (Gdx.input.isKeyJustPressed(Input.Keys.UP)){
            System.out.println("UP");
        }

        if (Gdx.input.isKeyJustPressed(Input.Keys.DOWN)){
            System.out.println("Down");
        }

        if (Gdx.input.isKeyJustPressed(Input.Keys.RIGHT)){
            System.out.println("Right");
        }

        if (Gdx.input.isKeyJustPressed(Input.Keys.LEFT)){
            System.out.println("Left");
        }
    }
}
