package Personajes;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.scenes.scene2d.Actor;


import java.awt.Rectangle;

import Objetos.Pelota;

public class Personaje extends Actor {
    private int vidas;
    private int fuerza;
    private int velocidad;
    Pelota pelota;
    private float width;
    private float height;
    private int positionx;
    private int positiony;
    private Texture imagen;
    private Rectangle hitbox;

    public int getVidas() {
        return vidas;
    }

    public void setVidas(int vidas) {
        this.vidas = vidas;
    }

    public int getFuerza() {
        return fuerza;
    }

    public void setFuerza(int fuerza) {
        this.fuerza = fuerza;
    }

    public int getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }

    @Override
    public float getWidth() {
        return width;
    }

    @Override
    public void setWidth(float width) {
        this.width = width;
    }

    @Override
    public float getHeight() {
        return height;
    }

    @Override
    public void setHeight(float height) {
        this.height = height;
    }

    public int getPositionx() {
        return positionx;
    }

    public void setPositionx(int positionx) {
        this.positionx = positionx;
    }

    public int getPositiony() {
        return positiony;
    }

    public void setPositiony(int positiony) {
        this.positiony = positiony;
    }

    public Texture getImagen() {
        return imagen;
    }

    public void setImagen(Texture imagen) {
        this.imagen = imagen;
    }

    public Rectangle getHitbox() {
        return hitbox;
    }

    public void setHitbox(Rectangle hitbox) {
        this.hitbox = hitbox;
    }

    public Personaje(int vidas, int fuerza, int velocidad, float width, float height, int positionx,
                     int positiony, Texture imagen, Rectangle hitbox) {
        this.vidas = vidas;
        this.fuerza = fuerza;
        this.velocidad = velocidad;
        this.width = width;
        this.height = height;
        this.positionx = positionx;
        this.positiony = positiony;
        this.imagen = imagen;
        this.hitbox = hitbox;
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        batch.draw(imagen,getX(),getY());
        super.draw(batch, parentAlpha);
    }

    public void move(){

        if (Gdx.input.isKeyPressed(Input.Keys.UP)){
            positiony += Gdx.graphics.getDeltaTime()*velocidad;

        }
        if (Gdx.input.isKeyPressed(Input.Keys.DOWN)){
            positiony -= Gdx.graphics.getDeltaTime()*velocidad;
        }
        if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)){
            positionx += Gdx.graphics.getDeltaTime()*velocidad;
        }
        if (Gdx.input.isKeyPressed(Input.Keys.LEFT)){
            positionx -= Gdx.graphics.getDeltaTime()*velocidad;
        }
    }

    public boolean Colision(Rectangle rectangle){
        Rectangle rectangle1 = new Rectangle(this.positionx,this.positiony);
        return true;
    }

    public void Lanzar(Pelota pelota){
        if (Gdx.input.isKeyPressed((Input.Keys.A))){
            pelota.lanzar();
        }
        if (Gdx.input.isKeyJustPressed(Input.Keys.B)){
            System.out.println("B");
        }
    }
}
