package Personajes;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.scenes.scene2d.Actor;

import Objetos.Pelota;

public class Personaje extends Actor {
    private int vidas = 3;
    private int fuerza = 1;
    private int velocidad = 100;
    Pelota pelota;
    private Vector3 position;

    private Texture jugador;

    public Personaje(int x,int y){
        position = new Vector3(x,y,0);
        jugador = new Texture("Perso.png");
    }

    public Texture getJugador(){
        return jugador;
    }
    public Vector3 getPosition(){
        return position;
    }
    //@Override
    //public void act(float delta){
      //  super.act(delta);
    //}

    @Override
    public void draw(Batch batch, float parentAlpha) {
        batch.draw(jugador,getX(),getY());
        super.draw(batch, parentAlpha);
    }

    public void updatePosition(){

    }

    public void move(){

        if (Gdx.input.isKeyPressed(Input.Keys.UP)){
            position.y += Gdx.graphics.getDeltaTime()*velocidad;

        }
        if (Gdx.input.isKeyPressed(Input.Keys.DOWN)){
            position.y -= Gdx.graphics.getDeltaTime()*velocidad;
        }
        if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)){
            position.x += Gdx.graphics.getDeltaTime()*velocidad;
        }
        if (Gdx.input.isKeyPressed(Input.Keys.LEFT)){
            position.x -= Gdx.graphics.getDeltaTime()*velocidad;
        }

    }

    public void Lanzar(Pelota pelota){
        if (Gdx.input.isKeyPressed((Input.Keys.A))){
            pelota.lanzar();
        }
        if (Gdx.input.isKeyJustPressed(Input.Keys.B)){
            System.out.println("B");
        }
    }
}
