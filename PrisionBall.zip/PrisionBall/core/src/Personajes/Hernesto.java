package Personajes;

import com.badlogic.gdx.graphics.Texture;

public class Hernesto  extends Personaje{
    public Hernesto(int vidas, int fuerza, int velocidad, float width, float height, int positionx, int positiony, Texture imagen) {
        super(vidas, fuerza, velocidad, width, height, positionx, positiony, imagen);
    }
}
