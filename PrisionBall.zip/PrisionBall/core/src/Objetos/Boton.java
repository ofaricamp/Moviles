package Objetos;

import com.badlogic.gdx.graphics.Texture;

import com.badlogic.gdx.math.Rectangle;

public class Boton {
    private float positionx;
    private float positiony;
    private float width;
    private float size;
    private Texture imagen;
    private Rectangle hit;

    public Boton(float positionx, float positiony, float width, float size, Texture imagen) {
        this.positionx = positionx;
        this.positiony = positiony;
        this.width = width;
        this.size = size;
        this.imagen = imagen;
        hit = new Rectangle(this.positionx,this.positiony,this.width,this.size);
    }


    public float getPositionx() {
        return positionx;
    }

    public void setPositionx(float positionx) {
        this.positionx = positionx;
    }

    public float getPositiony() {
        return positiony;
    }

    public void setPositiony(float positiony) {
        this.positiony = positiony;
    }

    public float getWidth() {
        return width;
    }

    public void setWidth(float width) {
        this.width = width;
    }

    public float getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public Texture getImagen() {
        return imagen;
    }

    public void setImagen(Texture imagen) {
        this.imagen = imagen;
    }

    public Rectangle getHit() {
        return hit;
    }

    public void setHit(Rectangle hit) {
        this.hit = hit;
    }
}
