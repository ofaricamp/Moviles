package Objetos;

import com.badlogic.gdx.graphics.Texture;

import com.badlogic.gdx.math.Rectangle;

public class Boton {
    private float positionx;
    private float positiony;
    private float width;
    private float height;
    private Texture imagen;
    private Rectangle hit;

    public Boton(float positionx, float positiony, float width, float height, Texture imagen) {
        this.positionx = positionx;
        this.positiony = positiony;
        this.width = width;
        this.height = height;
        this.imagen = imagen;
        hit = new Rectangle(this.positionx,this.positiony,this.width,this.height);
    }


    public float getPositionx() {
        return positionx;
    }

    public void setPositionx(float positionx) {
        this.positionx = positionx;
    }

    public float getPositiony() {
        return positiony;
    }

    public void setPositiony(float positiony) {
        this.positiony = positiony;
    }

    public float getWidth() {
        return width;
    }

    public void setWidth(float width) {
        this.width = width;
    }

    public float getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public Texture getImagen() {
        return imagen;
    }

    public void setImagen(Texture imagen) {
        this.imagen = imagen;
    }

    public Rectangle getHit() {
        return hit;
    }

    public void setHit(Rectangle hit) {
        this.hit = hit;
    }
}
