package Objetos;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.scenes.scene2d.Actor;

import javax.xml.transform.Templates;

public class Pelota extends Actor {

    private Texture textura;
    private int positionx;
    private int positiony;
    private float width;
    private float height;
    private int velocidad;

    public Pelota(Texture objeto, int positionx, int positiony, float width, float height, int velocidad) {
        this.textura = objeto;
        this.positionx = positionx;
        this.positiony = positiony;
        this.width = width;
        this.height = height;
        this.velocidad = velocidad;
    }

    public Texture getTextura() {
        return textura;
    }

    public void setTextura(Texture textura) {
        this.textura = textura;
    }

    public int getPositionx() {
        return positionx;
    }

    public void setPositionx(int positionx) {
        this.positionx = positionx;
    }

    public int getPositiony() {
        return positiony;
    }

    public void setPositiony(int positiony) {
        this.positiony = positiony;
    }

    @Override
    public float getWidth() {
        return width;
    }

    @Override
    public void setWidth(float width) {
        this.width = width;
    }

    @Override
    public float getHeight() {
        return height;
    }

    @Override
    public void setHeight(float height) {
        this.height = height;
    }

    public int getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }


    public int colision (Pelota pelota){
        if (pelota.positionx >= Gdx.graphics.getWidth()-pelota.width || pelota.positiony >= Gdx.graphics.getHeight()-pelota.height){
            return 1;
        }else if(pelota.positionx < 0 || pelota.positiony < 0){
            return -1;
        }
        return 0;
    }

    public void update(Pelota pelota){
        //System.out.println(colision(pelota));
        if (colision(pelota) == 1){
            pelota.velocidad = -pelota.velocidad;
        }else if (colision(pelota) == -1){
            pelota.velocidad = -pelota.velocidad;
        }
    }
    public void lanzar(){
        positionx += Gdx.graphics.getDeltaTime()*velocidad;
    }
}
