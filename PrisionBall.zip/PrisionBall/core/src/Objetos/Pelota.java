package Objetos;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.scenes.scene2d.Actor;

import javax.xml.transform.Templates;

public class Pelota extends Actor {

    Texture objeto;
    private Vector3 position;
    private int velocidad = 50;

    public Pelota(int x, int y){
        position = new Vector3(x,y,0);
        objeto = new Texture("pelota.png");
    }

    public Texture getObjeto(){
        return objeto;
    }

    public Vector3 getPosition(){return position;}

    @Override
    public void draw(Batch batch, float parentAlpha) {
        batch.draw(objeto,getX(),getY());
        super.draw(batch, parentAlpha);
    }
    public void lanzar(){
        position.x += Gdx.graphics.getDeltaTime()*velocidad;
    }
}
