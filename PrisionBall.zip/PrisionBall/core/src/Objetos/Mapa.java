package Objetos;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.Actor;

import java.awt.Rectangle;

import Personajes.Personaje;


public class Mapa extends Actor {
    private float width;
    private float height;
    private int positionx;
    private int posiitony;
    private Texture imagen;
    private Rectangle hitbox;
    private float positionxF;
    private float PositionyF;

    public Mapa(float width, float height, int positionx, int posiitony, Texture imagen,Rectangle hitbox) {
        this.width = width;
        this.height = height;
        this.positionx = positionx;
        this.posiitony = posiitony;
        this.imagen = imagen;
        this.hitbox = hitbox;
    }

    @Override
    public float getWidth() {
        return width;
    }

    @Override
    public void setWidth(float width) {
        this.width = width;
    }

    @Override
    public float getHeight() {
        return height;
    }

    @Override
    public void setHeight(float height) {
        this.height = height;
    }

    public int getPositionx() {
        return positionx;
    }

    public void setPositionx(int positionx) {
        this.positionx = positionx;
    }

    public int getPosiitony() {
        return posiitony;
    }

    public void setPosiitony(int posiitony) {
        this.posiitony = posiitony;
    }

    public Texture getImagen() {
        return imagen;
    }

    public void setImagen(Texture imagen) {
        this.imagen = imagen;
    }

    public Rectangle getHitbox() {
        return hitbox;
    }

    public void setHitbox(Rectangle hitbox) {
        this.hitbox = hitbox;
    }

    public float getPositionxF() {
        return positionxF;
    }

    public void setPositionxF(float positionxF) {
        this.positionxF = positionxF;
    }

    public float getPositionyF() {
        return PositionyF;
    }

    public void setPositionyF(float getPositionyF) {
        this.PositionyF = getPositionyF;
    }

    public boolean limiteDelMapaIzq(Personaje personaje){

        return personaje.getHitbox().getX() <= hitbox.getX() ||
                personaje.getHitbox().getY() <= hitbox.getY() ||
                personaje.getHitbox().getY()+personaje.getHeight() >= hitbox.getY()+hitbox.height;
    }

    public boolean limiteDelMapaDer(Personaje personaje){

        return personaje.getHitbox().getX()+personaje.getWidth() >= hitbox.getX()+hitbox.width ||
        			personaje.getHitbox().getY() <= hitbox.getY() ||
        			personaje.getHitbox().getY()+personaje.getHeight() >= hitbox.getY()+hitbox.height;
    }

    public boolean limiteDelMapaCentralIzq(Personaje personaje){
        return personaje.getHitbox().getX()+personaje.getWidth() >= width/2+hitbox.getX();
    }

    public boolean limiteDelMapaCentralDer(Personaje personaje){
        //System.out.println( personaje.getHitbox().getX() +" "+(width/2+hitbox.getX())+" "+width/2+" "+hitbox.getX());
        return personaje.getHitbox().getX() <= width/2+hitbox.getX();
    }
}
