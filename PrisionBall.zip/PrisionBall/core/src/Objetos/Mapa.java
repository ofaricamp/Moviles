package Objetos;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.Actor;

public class Mapa extends Actor {
    private float width;
    private float height;
    private int positionx;
    private int posiitony;
    private Texture imagen;

    public Mapa(float width, float height, int positionx, int posiitony, Texture imagen) {
        this.width = width;
        this.height = height;
        this.positionx = positionx;
        this.posiitony = posiitony;
        this.imagen = imagen;
    }

    @Override
    public float getWidth() {
        return width;
    }

    @Override
    public void setWidth(float width) {
        this.width = width;
    }

    @Override
    public float getHeight() {
        return height;
    }

    @Override
    public void setHeight(float height) {
        this.height = height;
    }

    public int getPositionx() {
        return positionx;
    }

    public void setPositionx(int positionx) {
        this.positionx = positionx;
    }

    public int getPosiitony() {
        return posiitony;
    }

    public void setPosiitony(int posiitony) {
        this.posiitony = posiitony;
    }

    public Texture getImagen() {
        return imagen;
    }

    public void setImagen(Texture imagen) {
        this.imagen = imagen;
    }


}
