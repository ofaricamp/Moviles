package com.mygdx.prisionball;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import java.awt.Rectangle;

import Objetos.Mapa;
import Objetos.Pelota;
import Personajes.Personaje;

public class Escenario implements Screen {
    SpriteBatch batch;
    Texture mapa;
    //private  int width;
    //private int height;
    Personaje personaje;
    Personaje personaje2;
    Pelota pelota;
    Mapa truemapa;

    public Escenario(PrisionBall prisionBall) {
        batch = new SpriteBatch();

        personaje = new Personaje(3,1,150,90,60,90,
                200,new Texture("Perso.png"),new Rectangle(90,200,90,60));

        personaje2 = new Personaje(3,1,250,90,60,350,
                200,new Texture("poxito.png"),new Rectangle(350,200,90,60));

        pelota = new Pelota(new Texture("pelota.png"),100,200,60,
                90,500,new Rectangle(100,2000,60,90));
        truemapa = new Mapa(495,226,Gdx.graphics.getWidth()/9,
                Gdx.graphics.getHeight()/3,new Texture("Campo.png"),
                new Rectangle(Gdx.graphics.getWidth()/3,
                        Gdx.graphics.getHeight()/9,495,226));
        truemapa.setPositionyF(truemapa.getPosiitony());
        truemapa.setPositionxF(truemapa.getPositionx());
    }

    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        truemapa.getHitbox().setLocation(truemapa.getPositionx(),truemapa.getPosiitony());
        personaje.getHitbox().setLocation(personaje.getPositionx(),personaje.getPositiony());
        personaje2.getHitbox().setLocation(personaje2.getPositionx(),personaje2.getPositiony());
        pelota.getHitbox().setLocation(pelota.getPositionx(),pelota.getPositiony());


        if (truemapa.limiteDelMapaIzq(personaje)){
            personaje.setVelocidad(0);
        }
        if (truemapa.limiteDelMapaDer(personaje2)){
            personaje2.setVelocidad(0);
        }
        if (truemapa.limiteDelMapaCentralIzq(personaje)){
            personaje.setVelocidad(0);
        }

        if (truemapa.limiteDelMapaCentralDer(personaje2)){
            personaje2.setVelocidad(0);
        }

        batch.begin();
        batch.draw(truemapa.getImagen(),truemapa.getPositionx(),truemapa.getPosiitony());
        batch.draw(personaje2.getImagen(),personaje2.getPositionx(),personaje2.getPositiony(),personaje2.getWidth(),personaje2.getHeight());
        batch.draw(personaje.getImagen(),personaje.getPositionx(),personaje.getPositiony(),personaje.getWidth(),personaje.getHeight());
        batch.draw(pelota.getTextura(), pelota.getPositionx(),pelota.getPositiony(),pelota.getWidth(),pelota.getHeight());

        personaje.move();
        personaje2.move();

        if(personaje.agarrar(pelota)){
            pelota.agarrada(true,personaje);
            pelota.update(pelota);
        }else{
            personaje.Lanzar(pelota);
            pelota.update(pelota);
        }

        pelota.colision(pelota);
        batch.end();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
