package com.mygdx.prisionball;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

import java.awt.Rectangle;

import Objetos.Mapa;
import Objetos.Pelota;
import Personajes.Personaje;

public class Escenario implements Screen {
    SpriteBatch batch;
    Camera camara;
    Viewport viewport;
    Texture mapa;
    Personaje [] personajes = {
            new Personaje("Antonio",3,1,150,90,60,90,
                    200,new Texture("Perso.png"),new Rectangle(90,200,90,60)),
            new Personaje("Dulver",2,1,150,90,60,90,
                    200,new Texture("Perso.png"),new Rectangle(90,200,90,60)),
            new Personaje("Hernesto",3,2,150,100,60,90,
                    200,new Texture("Perso.png"),new Rectangle(90,200,90,60)),
            new Personaje("MM",4,1,150,90,60,90,
                    200,new Texture("Perso.png"),new Rectangle(90,200,90,60)),
            new Personaje("Speedy",3,1,200,90,60,90,
                    200,new Texture("Perso.png"),new Rectangle(90,200,90,60))
    };
    Personaje personaje;
    Personaje personaje2;
    Pelota pelota;
    Mapa truemapa;

    public Escenario(PrisionBall prisionBall) {
        batch = new SpriteBatch();

        personaje = new Personaje("Pepe",3,1,150,90,60,90,
                200,new Texture("Perso.png"),new Rectangle(90,200,90,60));

        personaje2 = new Personaje("Poxito",3,1,250,90,60,350,
                200,new Texture("poxito.png"),new Rectangle(350,200,90,60));

        pelota = new Pelota(new Texture("pelota.png"),100,200,60,
                90,500,new Rectangle(100,2000,60,90));
        truemapa = new Mapa(495,226,Gdx.graphics.getWidth()/9,
                Gdx.graphics.getHeight()/3,new Texture("Campo.png"),
                new Rectangle(Gdx.graphics.getWidth()/3,
                        Gdx.graphics.getHeight()/9,495,226));
        truemapa.setPositionyF(truemapa.getPosiitony());
        truemapa.setPositionxF(truemapa.getPositionx());
        camara = new OrthographicCamera();
        viewport = new StretchViewport(prisionBall.WIDTH,prisionBall.HEIGHT,camara);
    }

    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        truemapa.getHitbox().setLocation(truemapa.getPositionx(),truemapa.getPosiitony());
        personaje.getHitbox().setLocation(personaje.getPositionx(),personaje.getPositiony());
        personaje2.getHitbox().setLocation(personaje2.getPositionx(),personaje2.getPositiony());
        pelota.getHitbox().setLocation(pelota.getPositionx(),pelota.getPositiony());


        if (truemapa.limiteDelMapaIzq(personaje)){
            //personaje.setVelocidad(0);
            //personaje.setPosition(personaje.getPositionx(),personaje.getPositiony());
            personaje.setPositionx(truemapa.getPositionx());
            personaje.setPositiony(truemapa.getPosiitony());
        }
        if (truemapa.limiteDelMapaDer(personaje2)){
            //personaje2.setVelocidad(0);
            //personaje2.setPosition(personaje2.getPositionx(),personaje2.getPositiony());
            personaje2.setPositionx(truemapa.getPositionx()+((int)(truemapa.getWidth()-personaje2.getWidth())));
            personaje2.setPositiony(personaje2.getPositiony()+((int)(truemapa.getHeight()-personaje.getHeight())));
        }
        if (truemapa.limiteDelMapaCentralIzq(personaje)){
            // personaje.setVelocidad(0);
           // personaje.setPosition(personaje.getPositionx(),personaje.getPositiony());
            personaje.setPositionx(truemapa.getPositionx());
            //personaje.setPositiony(truemapa.getPositiony());
        }

        if (truemapa.limiteDelMapaCentralDer(personaje2)){
            //personaje2.setVelocidad(0);
           // personaje2.setPosition(personaje2.getPositionx(),personaje2.getPositiony());
            personaje2.setPositionx(truemapa.getPositionx());
            //personaje2.setPositiony(truemapa.getPositiony());
        }


        batch.begin();
        batch.draw(truemapa.getImagen(),truemapa.getPositionx(),truemapa.getPosiitony());
        batch.draw(personaje2.getImagen(),personaje2.getPositionx(),personaje2.getPositiony(),personaje2.getWidth(),personaje2.getHeight());
        batch.draw(personaje.getImagen(),personaje.getPositionx(),personaje.getPositiony(),personaje.getWidth(),personaje.getHeight());
        batch.draw(pelota.getTextura(), pelota.getPositionx(),pelota.getPositiony(),pelota.getWidth(),pelota.getHeight());

        personaje.move();
        personaje2.move();

       // personaje.isGolepado() = pelota.getHitbox().intersects(personaje.getHitbox());
        if (personaje.isGolepado()){
            System.out.println(personaje.getVidas());
        }else{
            System.out.println("jaja");
        }
        if(personaje.agarrar(pelota)){
            pelota.agarrada(true,personaje);
        }else{
            personaje.Lanzar(pelota);
        }
        System.out.println("PersoY: "+personaje.getHitbox().getY());
        System.out.println("PersoX: "+personaje.getHitbox().getX());

        System.out.println("PelotaY: "+pelota.getHitbox().getY());
        System.out.println("PelotaX: "+pelota.getHitbox().getX());

        pelota.update(pelota);
        pelota.colision(pelota);
        batch.end();
    }

    @Override
    public void resize(int width, int height) {
       // viewport.update(width,height,true);
       // batch.setProjectionMatrix(camara.combined);
    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
