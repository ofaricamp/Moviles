package com.mygdx.prisionball;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.utils.ScreenUtils;

import Objetos.Pelota;
import Personajes.Personaje;

public class PrisionBall extends ApplicationAdapter {
	SpriteBatch batch;
	Texture img,mapa;
	private  int width;
	private int height;
	Personaje personaje;
	Pelota pelota;

	@Override
	public void create () {
		batch = new SpriteBatch();
		//img = new Texture("Perso.png");
		personaje = new Personaje(200,200);
		pelota = new Pelota(100,100);
		mapa = new Texture("Campo.png");
		width = Gdx.graphics.getWidth();
		height = Gdx.graphics.getHeight();
	}

	@Override
	public void render () {
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		batch.begin();

		batch.draw(mapa,-100,-100);
		//batch.draw(img,200,200);
		batch.draw(personaje.getJugador(),personaje.getPosition().x,personaje.getPosition().y);
		batch.draw(pelota.getObjeto(), pelota.getPosition().x,pelota.getPosition().y);
		personaje.move();
		personaje.Lanzar(pelota);
		batch.end();
	}
	
	@Override
	public void dispose () {
		batch.dispose();
		img.dispose();
	}
}
