package com.mygdx.prisionball;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Contact;
import com.badlogic.gdx.utils.ScreenUtils;


import java.awt.Rectangle;
import java.awt.geom.Line2D;

import javax.sound.sampled.Line;

import Objetos.Mapa;
import Objetos.Pelota;
import Personajes.Personaje;

public class PrisionBall extends Game {
	SpriteBatch batch;
	Menu menu;
	Escenario escenario;
	public static final float WIDTH = 1300;
	public static final float HEIGHT = 750;

	public void setMenu(){
		menu = new Menu(this);
		setScreen(menu);
	}
	public void setExcenarioScreen(){
		escenario = new Escenario(this);
		setScreen(escenario);
	}
	@Override
	public void create () {
		setMenu();
		//setExcenarioScreen();
	}

	@Override
	public void render () {
		super.render();
	}

	@Override
	public void resize(int width, int height){
		menu.resize(width,height);
		//escenario.resize(width,height);

	}
	@Override
	public void dispose () {
		batch.dispose();
	}
}
