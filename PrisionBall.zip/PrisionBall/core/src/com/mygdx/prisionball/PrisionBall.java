package com.mygdx.prisionball;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.physics.box2d.Contact;
import com.badlogic.gdx.utils.ScreenUtils;


import java.awt.Rectangle;
import java.awt.geom.Line2D;

import javax.sound.sampled.Line;

import Objetos.Mapa;
import Objetos.Pelota;
import Personajes.Personaje;

public class PrisionBall extends ApplicationAdapter {
	SpriteBatch batch;
	Texture mapa;
	//private  int width;
	//private int height;
	Personaje personaje;
	Personaje personaje2;
	Pelota pelota;
	Mapa truemapa;


//	Rectangle campoHitbox;
//	Rectangle personajeHitbox;
//	Rectangle personaje2Hitbox;
//	Rectangle pelotaHitBox;

	@Override
	public void create () {
		batch = new SpriteBatch();

		personaje = new Personaje(3,1,150,90,60,90,
				200,new Texture("Perso.png"),new Rectangle(90,200,90,60));

		personaje2 = new Personaje(3,1,250,90,60,350,
				200,new Texture("poxito.png"),new Rectangle(350,200,90,60));

		pelota = new Pelota(new Texture("pelota.png"),100,200,60,
				90,450,new Rectangle(100,2000,60,90));
		//mapa = new Texture("Campo.png");
		truemapa = new Mapa(495,226,Gdx.graphics.getWidth()/9,
				Gdx.graphics.getHeight()/3,new Texture("Campo.png"),
				new Rectangle(Gdx.graphics.getWidth()/3,
						Gdx.graphics.getHeight()/9,495,226));
		truemapa.setPositionyF(truemapa.getPosiitony());
		truemapa.setPositionxF(truemapa.getPositionx());

//		linea.line((truemapa.getPositionxF()+(truemapa.getPositionxF()/2)),
//			truemapa.getPositionyF(),(truemapa.getPositionxF()+(truemapa.getPositionxF()/2)),truemapa.getPositionyF());
		//width = Gdx.graphics.getWidth();
		//height = Gdx.graphics.getWidth();
	//	pelotaHitBox = pelota.getHitbox();
	//	campoHitbox = truemapa.getHitbox();
	//	personajeHitbox = personaje.getHitbox();
	//	personaje2Hitbox = personaje2.getHitbox();
	}

	@Override
	public void render () {
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

		truemapa.getHitbox().setLocation(truemapa.getPositionx(),truemapa.getPosiitony());
		personaje.getHitbox().setLocation(personaje.getPositionx(),personaje.getPositiony());
		personaje2.getHitbox().setLocation(personaje2.getPositionx(),personaje2.getPositiony());
		pelota.getHitbox().setLocation(pelota.getPositionx(),pelota.getPositiony());

	//	if (pelota.getHitbox().intersects(personaje.getHitbox())){
	//		System.out.println("Personaje1 golpiza");
	//	}
	//	if (pelota.getHitbox().intersects(personaje2.getHitbox())){
	//		System.out.println("Personaje2 fulminado");
	//	}

	//	if (personajeHitbox.getX() <= campoHitbox.getX() ||
	//			personajeHitbox.getY() <= campoHitbox.getY() ||
	//			personajeHitbox.getY()+personaje.getHeight() >= campoHitbox.getY()+campoHitbox.height){
	//		personaje.setVelocidad(0);
	//	}
	//	if (personaje2Hitbox.getX()+personaje2.getWidth() >= campoHitbox.getX()+campoHitbox.width ||
	//			personaje2Hitbox.getY() <= campoHitbox.getY() ||
	//			personaje2Hitbox.getY()+personaje2.getHeight() >= campoHitbox.getY()+campoHitbox.height){
	//		personaje2.setVelocidad(0);
	//	}

		if (truemapa.limiteDelMapaIzq(personaje)){
			personaje.setVelocidad(0);
		}
		if (truemapa.limiteDelMapaDer(personaje2)){
			personaje2.setVelocidad(0);
		}
		//System.out.println(personaje.getHitbox().getX() > (truemapa.getHitbox().getX()/2));
		//System.out.println(personaje.getHitbox().getX());
		//System.out.println(truemapa.getWidth()/2);
		if (truemapa.limiteDelMapaCentralIzq(personaje)){
			personaje.setVelocidad(0);
		}

		if (truemapa.limiteDelMapaCentralDer(personaje2)){
			personaje2.setVelocidad(0);
		}

		batch.begin();
		batch.draw(truemapa.getImagen(),truemapa.getPositionx(),truemapa.getPosiitony());
		batch.draw(personaje2.getImagen(),personaje2.getPositionx(),personaje2.getPositiony(),personaje2.getWidth(),personaje2.getHeight());
		batch.draw(personaje.getImagen(),personaje.getPositionx(),personaje.getPositiony(),personaje.getWidth(),personaje.getHeight());
		batch.draw(pelota.getTextura(), pelota.getPositionx(),pelota.getPositiony(),pelota.getWidth(),pelota.getHeight());


		personaje.move();
		personaje2.move();
		personaje.Lanzar(pelota);
		pelota.colision(pelota);
		pelota.update(pelota);
		batch.end();
	}
	
	@Override
	public void dispose () {
		batch.dispose();
	}
}
