package com.mygdx.prisionball;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.utils.ScreenUtils;

import Personajes.Personaje;

public class PrisionBall extends ApplicationAdapter {
	SpriteBatch batch;
	Texture img,mapa;
	private  int width;
	private int height;

	@Override
	public void create () {
		batch = new SpriteBatch();
		img = new Texture("Perso.png");
		mapa = new Texture("Campo.png");
		width = Gdx.graphics.getWidth();
		height = Gdx.graphics.getHeight();
	}

	@Override
	public void render () {
		//ScreenUtils.clear(1, 0, 0, 1);
		//batch.begin();
		//batch.draw(batch, 0, 0);
		//batch.end();
		//Gdx.gl.glClearColor(1,0,5,1);
		//Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		batch.begin();

		batch.draw(mapa,-100,-100);
		batch.draw(img,200,200);
		batch.end();
	}
	
	@Override
	public void dispose () {
		batch.dispose();
		img.dispose();
		//textureAtlas.dispose();
	}
}
