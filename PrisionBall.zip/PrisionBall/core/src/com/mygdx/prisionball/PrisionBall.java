package com.mygdx.prisionball;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.utils.ScreenUtils;

import java.awt.Button;
import java.awt.Rectangle;

import javax.sound.sampled.Line;

import Objetos.Mapa;
import Objetos.Pelota;
import Personajes.Personaje;

public class PrisionBall extends ApplicationAdapter {
	SpriteBatch batch;
	Texture mapa;
	private  int width;
	private int height;
	Personaje personaje;
	Personaje personaje2;
	Pelota pelota;
	Mapa truemapa;
	Rectangle campoHitbox;
	Rectangle personajeHitbox;
	Rectangle personaje2Hitbox;

	@Override
	public void create () {
		batch = new SpriteBatch();
		personaje = new Personaje(3,1,150,90,60,90,200,new Texture("Perso.png"));
		personaje2 = new Personaje(3,1,250,90,60,350,200,new Texture("poxito.png"));
		pelota = new Pelota(new Texture("pelota.png"),100,200,60,90,450);
		mapa = new Texture("Campo.png");
		truemapa = new Mapa(495,226,Gdx.graphics.getWidth()/9,
				Gdx.graphics.getHeight()/3,new Texture("Campo.png"));
		width = Gdx.graphics.getWidth();
		height = Gdx.graphics.getHeight();
		campoHitbox = new Rectangle(495,226);
		personajeHitbox = new Rectangle(90,60);
		personaje2Hitbox = new Rectangle(90,60);
	}

	@Override
	public void render () {
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

		campoHitbox.setLocation(truemapa.getPositionx(),truemapa.getPosiitony());
		personajeHitbox.setLocation(personaje.getPositionx(),personaje.getPositiony());
		personaje2Hitbox.setLocation(personaje2.getPositionx(),personaje2.getPositiony());


		if (personajeHitbox.getX() <= campoHitbox.getX() ||
				personajeHitbox.getY() <= campoHitbox.getY() ||
				personajeHitbox.getY()+personaje.getHeight() >= campoHitbox.getY()+campoHitbox.height){
			personaje.setVelocidad(0);
		}
		if (personaje2Hitbox.getX()+personaje2.getWidth() >= campoHitbox.getX()+campoHitbox.width ||
				personaje2Hitbox.getY() <= campoHitbox.getY() ||
				personaje2Hitbox.getY()+personaje2.getHeight() >= campoHitbox.getY()+campoHitbox.height){
			personaje2.setVelocidad(0);
		}

		batch.begin();
		batch.draw(truemapa.getImagen(),truemapa.getPositionx(),truemapa.getPosiitony());
		batch.draw(personaje2.getImagen(),personaje2.getPositionx(),personaje2.getPositiony(),personaje2.getWidth(),personaje2.getHeight());
		batch.draw(personaje.getImagen(),personaje.getPositionx(),personaje.getPositiony(),personaje.getWidth(),personaje.getHeight());
		batch.draw(pelota.getTextura(), pelota.getPositionx(),pelota.getPositiony(),pelota.getWidth(),pelota.getHeight());

		personaje.move();
		personaje2.move();
		personaje.Lanzar(pelota);
		pelota.colision(pelota);
		pelota.update(pelota);
		batch.end();
	}
	
	@Override
	public void dispose () {
		batch.dispose();
	}
}
